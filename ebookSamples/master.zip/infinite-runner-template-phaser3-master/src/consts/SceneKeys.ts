enum SceneKeys
{
	Preloader = 'preloader',
	Game = 'game',
	GameOver = 'game-over'
}

export default SceneKeys
