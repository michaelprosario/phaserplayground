enum AnimationKeys
{
	RocketMouseRun = 'rocket-mouse-run',
	RocketFlamesOn = 'rocket-flames-on',
	RocketMouseFall = 'rocket-mouse-fall',
	RocketMouseFly = 'rocket-mouse-fly',
	RocketMouseDead = 'rocket-mouse-dead'
}

export default AnimationKeys
